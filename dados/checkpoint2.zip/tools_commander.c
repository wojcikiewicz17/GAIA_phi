#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <termios.h>
#include <sys/stat.h>
#include <errno.h>

#include "headers/omega_zipraf.h"
#include "headers/omega_hash.h"

// Cores estilo DOS
#define BG_BLUE   "\033[44m"
#define FG_WHITE  "\033[37m"
#define FG_CYAN   "\033[36m"
#define FG_YELLOW "\033[33m"
#define RESET     "\033[0m"

static struct termios orig_termios;

static void disableRawMode(void) {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &orig_termios);
    printf("\033[?25h"); // mostra cursor
}

static void enableRawMode(void) {
    tcgetattr(STDIN_FILENO, &orig_termios);
    atexit(disableRawMode);
    struct termios raw = orig_termios;
    raw.c_lflag &= ~(ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
    printf("\033[?25l"); // oculta cursor
}

static void cls(void) {
    printf("\033[2J\033[H");
}

static void draw_bar(int y, const char* text) {
    printf("\033[%d;1H%s%s%-80s%s", y, BG_BLUE, FG_WHITE, text, RESET);
}

// -----------------------------------------------------------------------------
// Heurística para camada semântica por extensão
// -----------------------------------------------------------------------------
static SemanticLayer guess_layer(const char* filename) {
    if (!filename) return SEM_META_SELF;

    if (strstr(filename, ".c")   ||
        strstr(filename, ".h")   ||
        strstr(filename, ".py")  ||
        strstr(filename, ".rs"))   return SEM_CORE_LOGIC;

    if (strstr(filename, ".sh")  ||
        strstr(filename, ".conf")||
        strstr(filename, ".log"))  return SEM_SYS_ADMIN;

    if (strstr(filename, ".pem") ||
        strstr(filename, ".crt") ||
        strstr(filename, ".key"))  return SEM_NET_SEC;

    if (strstr(filename, ".json") ||
        strstr(filename, ".jsonl")||
        strstr(filename, ".txt")  ||
        strstr(filename, ".md"))   return SEM_HUMAN_CHAT;

    if (strstr(filename, ".png")  ||
        strstr(filename, ".jpg")  ||
        strstr(filename, ".jpeg") ||
        strstr(filename, ".webp")) return SEM_VISUAL_MEM;

    return SEM_META_SELF;
}

// Resolve tipo de entrada: arquivo ou diretório (fallback se d_type for 0)
static int is_directory(const char* base, const struct dirent* ent) {
    if (ent->d_type == DT_DIR) return 1;
    if (ent->d_type == DT_REG) return 0;

    // fallback via stat
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", base, ent->d_name);
    struct stat st;
    if (stat(path, &st) == 0) {
        return S_ISDIR(st.st_mode) ? 1 : 0;
    }
    return 0;
}

// -----------------------------------------------------------------------------
// Navegador de Arquivos / Absorção em ZipRaf
// -----------------------------------------------------------------------------
static void file_browser(const char* start_path) {
    struct dirent **namelist = NULL;
    int n;
    int selected      = 0;
    int scroll_offset = 0;
    char cwd[1024];

    strncpy(cwd, start_path, sizeof(cwd)-1);
    cwd[sizeof(cwd)-1] = '\0';

    for (;;) {
        cls();
        draw_bar(1, " GAIA-OMEGA COMMANDER [ZIPRAF ENGINE] ");
        printf("\033[2;1H%sPATH:%s %s%s", FG_YELLOW, RESET, cwd, RESET);

        n = scandir(cwd, &namelist, NULL, alphasort);
        if (n < 0) {
            perror("scandir");
            return;
        }

        int max_rows = 16;
        if (selected >= n) selected = (n > 0 ? n-1 : 0);
        if (selected < 0) selected = 0;

        for (int i = 0; i < max_rows; i++) {
            int idx = i + scroll_offset;
            printf("\033[%d;1H", 4 + i);
            if (idx >= n) {
                printf("                                                                                ");
                continue;
            }

            struct dirent* ent = namelist[idx];
            int is_dir = is_directory(cwd, ent);

            if (idx == selected) {
                printf("%s%s> %-40s%s", BG_BLUE, FG_WHITE, ent->d_name, RESET);
            } else {
                printf("  %-40s", ent->d_name);
            }

            if (is_dir) {
                printf(" [DIR]");
            } else {
                SemanticLayer l = guess_layer(ent->d_name);
                printf(" [LAYER %d]", l);
            }
        }

        draw_bar(22, " [UP/DWN] Navegar | [ENTER] Entrar/Absorver | [Q] Sair ");

        int c = getchar();
        if (c == 'q' || c == 'Q') {
            for (int i=0; i<n; i++) free(namelist[i]);
            free(namelist);
            break;
        }

        if (c == '\033') { // escape sequence
            int c1 = getchar();
            int c2 = getchar();
            if (c1 == '[') {
                if (c2 == 'A') { // up
                    if (selected > 0) selected--;
                    if (selected < scroll_offset) scroll_offset--;
                } else if (c2 == 'B') { // down
                    if (selected < n-1) selected++;
                    if (selected >= scroll_offset + max_rows) scroll_offset++;
                }
            }
        } else if (c == '\n' || c == '\r') {
            if (n == 0) continue;
            struct dirent* ent = namelist[selected];
            int is_dir = is_directory(cwd, ent);

            if (is_dir) {
                if (strcmp(ent->d_name, ".") == 0) {
                    // nada
                } else if (strcmp(ent->d_name, "..") == 0) {
                    // subir
                    char* slash = strrchr(cwd, '/');
                    if (slash && slash != cwd) {
                        *slash = '\0';
                    } else {
                        // volta para / ou mantém
                        strcpy(cwd, "/");
                    }
                } else {
                    size_t len = strlen(cwd);
                    if (len + 1 + strlen(ent->d_name) < sizeof(cwd)) {
                        if (strcmp(cwd, "/") != 0)
                            strcat(cwd, "/");
                        strcat(cwd, ent->d_name);
                    }
                }
                selected      = 0;
                scroll_offset = 0;
            } else {
                // Arquivo → Absorver para ZipRaf
                char fullpath[2048];
                snprintf(fullpath, sizeof(fullpath), "%s/%s", cwd, ent->d_name);

                SemanticLayer l = guess_layer(ent->d_name);

                draw_bar(23, " ABSORVENDO ARQUIVO PARA ZIPRAF... ");
                printf("\033[24;1H%s[INFO]%s %s → camada %d\n",
                       FG_CYAN, RESET, ent->d_name, (int)l);

                int res = zipraf_ingest(fullpath, ent->d_name, l);
                if (res == 0) {
                    printf("\033[25;1H%s[SUCCESS]%s '%s' indexado em layer_%d.zrf\n",
                           FG_CYAN, RESET, ent->d_name, (int)l);
                } else {
                    printf("\033[25;1H[ERROR] falha ao absorver '%s' (code=%d)\n",
                           ent->d_name, res);
                }
                fflush(stdout);
                usleep(600000); // ~0.6s
            }
        }

        for (int i=0; i<n; i++) free(namelist[i]);
        free(namelist);
    }
}

int main(void) {
    zipraf_init_db();
    enableRawMode();

    char cwd[1024];
    if (!getcwd(cwd, sizeof(cwd))) {
        strcpy(cwd, ".");
    }

    file_browser(cwd);

    disableRawMode();
    cls();
    printf("GAIA COMMANDER ENCERRADO.\n");
    return 0;
}
