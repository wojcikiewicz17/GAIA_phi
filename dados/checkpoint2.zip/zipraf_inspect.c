#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "headers/omega_protocol.h"
#include "headers/omega_zipraf.h"

static void inspect_layer(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) {
        perror("[inspect] fopen");
        return;
    }

    ZipRafHeader h;
    if (fread(&h, sizeof(h), 1, f) != 1) {
        fprintf(stderr, "[inspect] Falha ao ler header de %s\n", path);
        fclose(f);
        return;
    }

    printf("=== %s ===\n", path);
    printf(" magic      : 0x%08X\n", h.magic);
    printf(" version    : %u\n", h.version);
    printf(" layer_id   : %u\n", h.layer_id);
    printf(" crc32      : 0x%08X\n", h.crc32);
    printf(" entry_count: %llu\n",
           (unsigned long long)h.entry_count);
    printf(" data_offset: %llu\n\n",
           (unsigned long long)h.data_offset);

    if (h.entry_count == 0) {
        fclose(f);
        return;
    }

    // Vai até o início dos dados
    if (fseek(f, (long)h.data_offset, SEEK_SET) != 0) {
        fprintf(stderr, "[inspect] fseek falhou\n");
        fclose(f);
        return;
    }

    // Mostra no máximo os 16 primeiros
    unsigned long to_show = (h.entry_count < 16) ? h.entry_count : 16;
    for (unsigned long i = 0; i < to_show; i++) {
        ZipRafEntry e;
        if (fread(&e, sizeof(e), 1, f) != 1) {
            fprintf(stderr, "[inspect] fim inesperado em %s\n", path);
            break;
        }
        printf("  [%02lu] hash=%llu  doc_ref_id=%llu  vec=(%.4f, %.4f, %.4f)\n",
               i,
               (unsigned long long)e.semantic_hash,
               (unsigned long long)e.doc_ref_id,
               (double)e.vector[0], (double)e.vector[1], (double)e.vector[2]);
    }

    fclose(f);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Uso: %s semantics/layer_3.zrf [outro_layer.zrf ...]\n", argv[0]);
        return 0;
    }

    for (int i = 1; i < argc; i++) {
        inspect_layer(argv[i]);
        printf("\n");
    }
    return 0;
}
