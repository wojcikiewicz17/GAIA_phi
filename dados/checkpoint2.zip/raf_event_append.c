#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "headers/raf_event_log.h"

// Uso:
//   ./raf_event_append <log_path> <actor_id> <etype> "payload"
int main(int argc, char** argv) {
    if (argc < 5) {
        fprintf(stderr,
            "Uso: %s <log_path> <actor_id> <etype> \"payload\"\n"
            "Exemplo: %s raf_events.log 1 100 \"SNAPSHOT RAFAELIA_DB_FINAL_33.zipraf\"\n",
            argv[0], argv[0]);
        return 1;
    }

    const char* log_path = argv[1];
    uint32_t actor = (uint32_t)strtoul(argv[2], NULL, 10);
    uint32_t etype = (uint32_t)strtoul(argv[3], NULL, 10);
    const char* payload = argv[4];

    if (strchr(payload, '|') != NULL) {
        fprintf(stderr, "[RAF_LOG] Payload não pode conter '|'.\n");
        return 1;
    }

    int r = raf_append_event(log_path, actor, etype, payload);
    if (r != 0) {
        fprintf(stderr, "[RAF_LOG] Falha ao append de evento.\n");
        return 1;
    }

    printf("[RAF_LOG] Evento anexado em '%s'.\n", log_path);
    return 0;
}
