#include "headers/omega_protocol.h"
#include "headers/omega_asm.h"
#include "headers/omega_lexicon.h"
#include "headers/omega_plasticity.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void execute_by_id(int id, VectorVerb* v) { printf("Exec ID: %d\n", id); }
void recursive_read(char* buffer, int idx) {
    int c = getchar();
    if (c == '\n' || c == EOF) { buffer[idx] = '\0'; return; }
    buffer[idx] = (char)c;
    recursive_read(buffer, idx + 1);
}
void mutant_repl(struct SynapseNode* cortex) {
    char buf[256]; printf("\nΩ [MUTANT] > "); recursive_read(buf, 0);
    if(buf[0]=='q') return;
    printf("CMD: %s\n", buf);
    mutant_repl(cortex);
}
int main() {
    printf("GAIA MUTANT\n");
    struct SynapseNode* c = build_genesis_cortex();
    mutant_repl(c);
    return 0;
}
