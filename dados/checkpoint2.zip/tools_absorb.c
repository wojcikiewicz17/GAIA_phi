#include "headers/omega_protocol.h"
#include "headers/omega_nexus.h"
#include "headers/omega_hash.h"
#include "headers/omega_vision.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void ingest_json(FILE* f) { printf("JSON Ingested.\n"); } 
void ingest_img(const char* p) { printf("IMG Ingested: %s\n", p); }
int main(int argc, char** argv) {
    if(argc < 3) return 1;
    nexus_init(argv[1], 1000000);
    if(strstr(argv[3], "img")) ingest_img(argv[2]);
    else { FILE* f = fopen(argv[2], "r"); if(f){ ingest_json(f); fclose(f); } }
    nexus_close(); return 0;
}
