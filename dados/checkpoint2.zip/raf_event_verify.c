#include <stdio.h>
#include <stdlib.h>
#include "headers/raf_event_log.h"

// Uso:
//   ./raf_event_verify <log_path>
int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr,
            "Uso: %s <log_path>\n"
            "Exemplo: %s raf_events.log\n",
            argv[0], argv[0]);
        return 1;
    }

    const char* log_path = argv[1];
    int r = raf_verify_log(log_path);
    if (r != 0) {
        fprintf(stderr, "[RAF_LOG] Verificação FALHOU.\n");
        return 1;
    }
    return 0;
}
