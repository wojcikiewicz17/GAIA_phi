#include "headers/omega_protocol.h"
#include "headers/omega_nexus.h"
#include "headers/omega_hash.h"
#include "headers/omega_gui.h"
#include <stdio.h>
#include <string.h>
extern NexusHeader* header_ptr;
extern NexusCell* cells_ptr;
static int found = 0;
void on_match(NexusCell* c) { found = 1; }
int main() {
    nexus_init("gaia.nexus", 1000000);
    VectorVerb v = { .dimension = 3, .data = (float[]){0,0,0} };
    while(1) {
        gui_clear();
        gui_draw_box(1,1,60,10,"GAIA VISUAL");
        if(header_ptr) gui_render_radar(&v, header_ptr, cells_ptr);
        printf("\nCMD> "); char buf[64]; if(!fgets(buf,60,stdin)) break;
        if(buf[0]=='q') break;
        uint64_t h = semantic_hash_djb2(buf); hash_to_vector(h, &v);
        found=0; nexus_scan_match(&v, on_match);
    }
    nexus_close(); return 0;
}
