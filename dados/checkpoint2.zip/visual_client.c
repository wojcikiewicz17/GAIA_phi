#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/time.h>
#include "headers/omega_ipc.h"
#include "headers/omega_gui.h"
#include "headers/omega_hash.h"
int transaction(IPCRequest* req, IPCResponse* resp) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd == -1) return 0;
    struct sockaddr_un addr; memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX; strncpy(addr.sun_path, GAIA_SOCKET_PATH, sizeof(addr.sun_path)-1);
    if(connect(fd, (struct sockaddr*)&addr, sizeof(addr)) == -1) { close(fd); return 0; }
    write(fd, req, sizeof(IPCRequest)); read(fd, resp, sizeof(IPCResponse));
    close(fd); return 1;
}
int main() {
    char buf[128]; IPCRequest req; IPCResponse resp;
    while(1) {
        printf("\nCLIENT> "); if(!fgets(buf, 120, stdin)) break;
        buf[strcspn(buf, "\n")] = 0; if(strcmp(buf,"exit")==0) break;
        memset(&req, 0, sizeof(req)); req.opcode = OP_SEARCH;
        uint64_t h = semantic_hash_djb2(buf);
        req.vector[0] = (float)(h&0xFFFF)/65535.0; req.vector[1] = (float)((h>>16)&0xFFFF)/65535.0; req.vector[2] = (float)((h>>32)&0xFFFF)/65535.0;
        if(transaction(&req, &resp)) printf("STATUS: %d | MATCH: %s\n", resp.status, resp.best_match.action_tag);
        else printf("DAEMON OFFLINE.\n");
    }
    return 0;
}
