#include "headers/omega_protocol.h"
#include "headers/omega_nexus.h"
#include "headers/omega_hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LINE 4096
int main(int argc, char** argv) {
    if (argc < 2) return 1;
    if (nexus_init(argv[1], 1000000) != 0) return 1;
    char line[MAX_LINE]; unsigned long count = 0;
    while (fgets(line, MAX_LINE, stdin)) {
        line[strcspn(line, "\n")] = 0;
        if(strlen(line) < 2 || line[0] == '#') continue;
        uint64_t h = omega_hash(line);
        omega_float vec[3];
        vec[0] = (float)(h&0xFFFF)/65535.0; vec[1] = (float)((h>>16)&0xFFFF)/65535.0; vec[2] = (float)((h>>32)&0xFFFF)/65535.0;
        VectorVerb v = { .data = vec, .dimension = 3 };
        nexus_append(&v, line);
        count++;
    }
    printf("Total: %lu\n", count);
    nexus_close();
    return 0;
}
