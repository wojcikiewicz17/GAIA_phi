#include <stdio.h>
#include "fiber_hash.h"
#include "fiber_hash_lanes6.h"

static void print_hex(const fiber_u8 *h, fiber_size_t len) {
    fiber_size_t i;
    for (i = 0u; i < len; ++i) {
        printf("%02x", (unsigned int)h[i]);
    }
}

int main(void) {
    const fiber_u8 msg1[] = "hello world";
    const fiber_u8 msg2[] = "RAFAELIA FIBER-H LANES6 MODE";
    fiber_u8 h_scalar[32];
    fiber_u8 h_lanes6[32];

    /* Test 1: msg1 */
    fiber_h(msg1, (fiber_size_t)(sizeof(msg1) - 1u), h_scalar);
    fiber_h_lanes6(msg1, (fiber_size_t)(sizeof(msg1) - 1u), h_lanes6);

    printf("msg1=\"%s\"\n", msg1);
    printf("  FIBER-H scalar : ");
    print_hex(h_scalar, (fiber_size_t)32u);
    printf("\n");
    printf("  FIBER-H lanes6 : ");
    print_hex(h_lanes6, (fiber_size_t)32u);
    printf("\n\n");

    /* Test 2: msg2 */
    fiber_h(msg2, (fiber_size_t)(sizeof(msg2) - 1u), h_scalar);
    fiber_h_lanes6(msg2, (fiber_size_t)(sizeof(msg2) - 1u), h_lanes6);

    printf("msg2=\"%s\"\n", msg2);
    printf("  FIBER-H scalar : ");
    print_hex(h_scalar, (fiber_size_t)32u);
    printf("\n");
    printf("  FIBER-H lanes6 : ");
    print_hex(h_lanes6, (fiber_size_t)32u);
    printf("\n");

    return 0;
}
