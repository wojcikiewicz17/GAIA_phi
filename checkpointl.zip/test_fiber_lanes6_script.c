#include <stdio.h>          /* Apenas para debug/print no teste */
#include "fiber_hash.h"
#include "fiber_ops.h"

/* Dump simples em hex (debug only, fora do hot path). */
static void hex_print(const fiber_u8 *buf, fiber_size_t len)
{
    fiber_size_t i;
    for (i = 0; i < len; ++i) {
        printf("%02x", (unsigned int)buf[i]);
    }
}

/* Gera um bloco de 32 bytes sintético só para teste. */
static void build_demo_block(fiber_u8 out[32])
{
    fiber_size_t i;
    for (i = 0; i < 32; ++i) {
        out[i] = (fiber_u8)(i * 7u + 0x3Du);
    }
}

int main(void)
{
    fiber_u8 lanes[6][32];
    fiber_u8 block[32];
    fiber_u8 hash_before[32];
    fiber_u8 hash_after[32];
    fiber_size_t i;

    /* Script RAFAELIA simples (pode trocar pelos teus tokens). */
    const fiber_u8 script[] = {
        (fiber_u8)'R', (fiber_u8)'A', (fiber_u8)'F',
        (fiber_u8)'0', (fiber_u8)'1', (fiber_u8)'2'
    };

    /* Preencher block sintético. */
    build_demo_block(block);

    /* Inicializar lanes a partir desse bloco (exemplo: 6 cópias com offset). */
    for (i = 0; i < 6u; ++i) {
        fiber_size_t j;
        for (j = 0; j < 32u; ++j) {
            lanes[i][j] = (fiber_u8)(block[j] ^ (fiber_u8)(i * 0x11u));
        }
    }

    /* Hash escalar do bloco base. */
    fiber_h(block, (fiber_size_t)32u, hash_before);

    /* Aplicar script de micro-ops sobre as lanes. */
    fiber_lanes6_apply_script(
        lanes,
        script,
        (fiber_size_t)(sizeof(script) / sizeof(script[0]))
    );

    /* Compactar lanes em um novo bloco de 32 bytes (XOR de todas as lanes). */
    for (i = 0; i < 32u; ++i) {
        fiber_u8 acc = 0u;
        fiber_size_t lane;
        for (lane = 0; lane < 6u; ++lane) {
            acc ^= lanes[lane][i];
        }
        block[i] = acc;
    }

    /* Hash após as micro-ops. */
    fiber_h(block, (fiber_size_t)32u, hash_after);

    /* Mostrar resultado. */
    printf("[*] FIBER-H lanes6 micro-ops demo\n");
    printf("hash_before:\n");
    hex_print(hash_before, (fiber_size_t)32u);
    printf("\n");

    printf("hash_after :\n");
    hex_print(hash_after, (fiber_size_t)32u);
    printf("\n");

    return 0;
}
