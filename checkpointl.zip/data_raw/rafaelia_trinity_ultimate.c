/*  ... TODO: aqui fica TODO o código COMPLETO que você já tem ...
 *  abaixo só mostro o trecho ALTERADO do main
 */

int main(int argc, char *argv[]) {
    static TrinitySystem SYS;
    _init(&SYS);

    // CLI MODE (Automation / Pipes)
    if (argc > 1) {
        if (strcmp(argv[1], "--ingest") == 0) {
            _process_stream(&SYS, stdin);

            if (argc > 2 && strcmp(argv[2], "--svg") == 0) {
                // NEW: always print audit to stderr + SVG to stdout
                _audit_report(&SYS);      // métricas ISO/NIST (stderr)
                _render_svg(&SYS);        // grafo HDC (stdout)
            } else {
                _audit_report(&SYS);      // só relatório textual
            }
            return 0;
        }
    }

    /* ... resto do BBS exatamente como já está ... */
}
