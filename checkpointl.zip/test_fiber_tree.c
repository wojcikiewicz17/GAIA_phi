#include <stdio.h>
#include "fiber_hash.h"

/* Simple helper: print 32-byte digest in hex */
static void print_hex(const fiber_u8 *h)
{
    fiber_size_t i;
    for (i = 0u; i < (fiber_size_t)32u; ++i) {
        printf("%02x", (unsigned int)h[i]);
    }
}

/* Test driver for fiber_h_tree:
 * - hashes a few messages with different leaf sizes
 * - prints results so you can compare stability.
 */
int main(void)
{
    const fiber_u8 msg1[] =
        "The quick brown fox jumps over the lazy dog";
    const fiber_u8 msg2[] =
        "RAFAELIA_CORE v1.1-Ω – ΣΩΔΦBITRAF + RAFCODE-Φ + Pre6";

    fiber_u8 out[32];

    printf("[*] FIBER-H tree mode tests\n");

    /* Test 1: msg1, leaf 1024 */
    fiber_h_tree(msg1,
                 (fiber_size_t)(sizeof(msg1) - 1u),
                 out,
                 (fiber_size_t)1024u);
    printf("msg1, leaf=1024 : ");
    print_hex(out);
    printf("\n");

    /* Test 2: msg1, leaf 64 */
    fiber_h_tree(msg1,
                 (fiber_size_t)(sizeof(msg1) - 1u),
                 out,
                 (fiber_size_t)64u);
    printf("msg1, leaf=64   : ");
    print_hex(out);
    printf("\n");

    /* Test 3: msg2, leaf 128 */
    fiber_h_tree(msg2,
                 (fiber_size_t)(sizeof(msg2) - 1u),
                 out,
                 (fiber_size_t)128u);
    printf("msg2, leaf=128  : ");
    print_hex(out);
    printf("\n");

    /* Test 4: empty message, leaf=0 (default) */
    fiber_h_tree((const fiber_u8 *)"", (fiber_size_t)0u, out, (fiber_size_t)0u);
    printf("empty, leaf=0   : ");
    print_hex(out);
    printf("\n");

    return 0;
}
