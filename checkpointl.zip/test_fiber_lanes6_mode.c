/*
 * test_fiber_lanes6_mode.c
 * ------------------------
 * Testa o modo RAFAELIA (6 lanes + script) sobre FIBER-H escalar.
 * Saída: compara FIBER-H "puro" vs FIBER-H_LANES6_SCRIPT.
 */

#include <stdio.h>
#include <string.h>

#include "fiber_hash.h"

/* Protótipo do modo RAFAELIA (fiber_lanes6_mode.c). */
void fiber_h_lanes6_script_hash(
    const fiber_u8 *msg,
    fiber_size_t msg_len,
    const fiber_u8 *script,
    fiber_size_t script_len,
    fiber_u8 out[32]
);

/* Impressão em hex simples, sem libs extras. */
static void print_hex(const fiber_u8 *buf, fiber_size_t len) {
    static const char HEX[17] = "0123456789abcdef";
    fiber_size_t i;
    for (i = (fiber_size_t)0u; i < len; ++i) {
        fiber_u8 b  = buf[i];
        char hi = HEX[(b >> 4) & (fiber_u8)0x0Fu];
        char lo = HEX[b & (fiber_u8)0x0Fu];
        putchar(hi);
        putchar(lo);
    }
}

/* Helper para uma mensagem + script. */
static void run_case(const char *label, const char *msg, const char *script_str) {
    fiber_u8 h_scalar[32];
    fiber_u8 h_lanes[32];
    const fiber_u8 *m = (const fiber_u8 *)msg;
    const fiber_u8 *s = (const fiber_u8 *)script_str;
    fiber_size_t mlen = (fiber_size_t)strlen(msg);
    fiber_size_t slen = (fiber_size_t)strlen(script_str);

    printf("\n[%s]\n", label);
    printf("  msg    : \"%s\"\n", msg);
    printf("  script : \"%s\"\n", script_str);

    /* FIBER-H escalar. */
    fiber_h(m, mlen, h_scalar);
    printf("  FIBER-H scalar        : ");
    print_hex(h_scalar, (fiber_size_t)32u);
    putchar('\n');

    /* FIBER-H RAFAELIA LANES6 + script. */
    fiber_h_lanes6_script_hash(m, mlen, s, slen, h_lanes);
    printf("  FIBER-H lanes6-script : ");
    print_hex(h_lanes, (fiber_size_t)32u);
    putchar('\n');
}

int main(void) {
    const char *script = "RAFCODE-Φ-BITRAF64";

    puts("[*] FIBER-H LANES6 RAFAELIA MODE TEST");

    run_case("case1", "hello world", script);
    run_case("case2", "RAFAELIA FIBER-H LANES6 MODE", script);
    run_case("case3", "ΣΩΔΦBITRAF kernel vivo", script);

    puts("\n[*] Done.");
    return 0;
}
